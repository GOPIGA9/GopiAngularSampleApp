import { TestBed, async, ComponentFixture, fakeAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { ApiCallsService } from './api-calls.service';
import { HomeComponent } from './home/home.component';
describe('AppComponent', () => {
  let fixture = TestBed.createComponent(AppComponent);
  let app = fixture.componentInstance;
  fixture.detectChanges();
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AppComponent, HomeComponent],
      providers: [ApiCallsService],
    }).compileComponents().then(() => {
       fixture = TestBed.createComponent(AppComponent);
       app = fixture.componentInstance;
      fixture.detectChanges();
    });;
  }));



  describe("should create the app", () => {
    it('should create the app', fakeAsync(() => {
      expect(app).toBeTruthy();
    }));
  });

  describe("should have as title 'SapientTest'", () => {
  it(`should have as title 'SapientTest'`, () => {
    expect(app.title).toEqual('SapientTest');
    });
  })

  describe("should render title", () => {
    it('should render title', () => {
      const compiled = fixture.nativeElement;
      expect(compiled.querySelector('.content span').textContent).toContain(
        'SapientTest app is running!'
      );
    });
  })



});
